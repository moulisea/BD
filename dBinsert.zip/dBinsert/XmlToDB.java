package org.venki.parser.jaxb.dBinsert;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;


import org.venki.parser.jaxb.Student;

public class XmlToDB {
	public static void main(String args[]) {

		// path of xml file to be converted
		File file = new File("F:\\DATA\\XMLtoDB.xml");

		// adding annotated class to JAXB API context
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(Employee.class);

			// obtain unmarshaller object to manipulate xml
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

			// getting java object and casting it to required type
			Employee employee = (Employee) jaxbUnmarshaller.unmarshal(file);

			// printing object to console
			System.out.println(employee);
		} 

		catch (JAXBException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		/*Connection c = null;
		Statement stmt = null;
		try {
			Class.forName("org.postgresql.Driver");
			c = DriverManager
					.getConnection("jdbc:postgresql://localhost:5432/hibernatedb",
							"postgres", "password");

			stmt = c.createStatement();
			String sql = "INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) VALUES (1, 'Paul', 32, 'California', 20000.00);";
			stmt.executeUpdate(sql);
			stmt.close();
			c.close();

		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getClass().getName()+": "+e.getMessage());
			System.exit(0);
		}
		System.out.println("Opened database successfully");*/
	}
}

