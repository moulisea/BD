package org.venki.parser.jaxb.dBinsert;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "employee")
public class Employee {

	@XmlAttribute
	private int id;
	private String name;
	private String department;
	private Address address;

	// XmLElementWrapper generates a wrapper element around XML representation 
	@XmlElementWrapper(name = "stateList") 
	// XmlElement sets the name of the entities in collection 
	@XmlElement(name = "state") 

	private ArrayList<State> listOfStates;

	//Must have no-argument constructor
	public Employee() { }

	public Employee(int id, String name, String department, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.department = department;
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	public ArrayList<State> getListOfStates() {
		return listOfStates; 
	} 


	public void setListOfStates(ArrayList<State> listOfStates) {
		this.listOfStates = listOfStates; 
	}

	public static String listToString(List<?> list) {
	    String result = "+";
	    for (int i = 0; i < list.size(); i++) {
	        result += " " + list.get(i);
	    }
	    return result;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", department="
				+ department + ", address=" + address + ", listOfStates="
				+ listOfStates.get(0).getStateName() +","+listOfStates.get(1).getStateName()+
				
				"]";
	}   
}